export const ErrorMessage = ({ message }) => {
  return <p>{message}</p>;
};
