export const FILTER_DEFAULT_VALUE = 'none';
