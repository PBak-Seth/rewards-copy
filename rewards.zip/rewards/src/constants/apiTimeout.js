export const API_TIMEOUT = 700;
